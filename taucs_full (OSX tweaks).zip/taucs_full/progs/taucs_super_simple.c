#include <taucs.h>
int main(int argc, char* argv[])
{
  double x = taucs_get_nan();
  return 1;
}
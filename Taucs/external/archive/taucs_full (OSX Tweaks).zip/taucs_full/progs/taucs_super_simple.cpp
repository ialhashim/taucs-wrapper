#include <complex>
extern "C"{
#include <taucs.h>
}
using namespace std;
int main(int argc, char* argv[])
{
  double x = taucs_get_nan();
  return 1;
}